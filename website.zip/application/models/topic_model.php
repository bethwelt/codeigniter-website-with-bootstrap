<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Topic_model extends CI_Model {

	public function __construct()
	{
		//$this->load->database();
	}

	public function get_all()
	{
         $cat=$_GET["cat_Id"];
                $cat_id = $this->input->get('$cat', TRUE);
                echo $cat_id;
		$query = $this->db->get_where('tbl_topic', array('cat_id' => $cat_id), $limit, $offset);
		return $query->result_array();
	}



}
