<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Slogin_model extends CI_Model {

	public function __construct()
	{
		//$this->load->database();
	}

	public function get_all()
	{
		$query = $this->db->get('tbl_topic');
		return $query->result_array();
	}



}
