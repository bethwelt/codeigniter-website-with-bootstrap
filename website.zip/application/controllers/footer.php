<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Footer extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Footer_model');
	}

	public function index()
	{	
		$this->data['title'] = 'Template';

		//$this->data['products'] = $this->Products_model->get_all();
		
		$this->load->view('footer', $this->data);
	}
}
