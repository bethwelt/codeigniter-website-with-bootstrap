<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Shome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Shome_model');
	}

	public function index()
	{	
		$this->data['title'] = 'dashboard';

		$this->data['shome'] = $this->Shome_model->get_all();
                $this->load->view('header');
		
		$this->load->view('student/home', $this->data);


			$this->load->view('footer');
		//}
	}
}
