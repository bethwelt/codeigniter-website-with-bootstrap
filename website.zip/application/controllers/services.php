<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Services extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Services_model');
	}

	public function index()
	{	
		$this->data['title'] = 'Services';

		$this->data['courses'] = $this->Courses_model->get_all();
		$this->load->view('header2');
		$this->load->view('pages/services', $this->data);
                //$this->load->library('pagination');
                //$config['base_url'] = '../index.php/courses';
                //$config['total_rows'] = 200;
                //$config['per_page'] = 20;
                //$this->pagination->initialize($config);
                //echo $this->pagination->create_links();
                $this->load->view('footer2');
	}
}
