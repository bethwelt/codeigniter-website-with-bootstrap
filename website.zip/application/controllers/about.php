<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class About extends CI_Controller {

	public function __construct()
	{ 
		parent::__construct();
		$this->load->model('About_model');
	}

	public function index()
	{	
		$this->data['title'] = 'About';

		$this->data['about'] = $this->About_model->get_all();
		$this->load->view('header2');
		$this->load->view('pages/about', $this->data);
                //$this->load->library('pagination');
                //$config['base_url'] = 'index.php/about';
                //$config['total_rows'] = 200;
                //$config['per_page'] = 20;
                //$this->pagination->initialize($config);

                //echo $this->pagination->create_links();
                $this->load->view('footer2');
	}
}
