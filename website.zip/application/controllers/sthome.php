<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class StHome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('StHome_model');
	}

	public function index()
	{	
		$this->data['title'] = 'Home';

		//$this->data['products'] = $this->Products_model->get_all();
		$this->load->view('header');
		$this->load->view('student/index', $this->data);
                $this->load->view('footer');
	}
}
