<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Blog extends CI_Controller {

       public function __construct()
       {
            parent::__construct();
            // Your own constructor
            $this->load->model('Create_model');
       }

	public function create()
{
	$this->load->helper('form');
	$this->load->library('form_validation');
	
	$data['title'] = 'Create a news item';
	
	$this->form_validation->set_rules('title', 'Title', 'required');
	$this->form_validation->set_rules('text', 'text', 'required');
	
	if ($this->form_validation->run() === FALSE)
	{
		$this->load->view('header', $data);	
		$this->load->view('blog/create');
		$this->load->view('footer');
		
	}
	else
	{
		$this->news_model->set_news();
		$this->load->view('blog/success');
                //echo 'successfully added';
	}
}
}
