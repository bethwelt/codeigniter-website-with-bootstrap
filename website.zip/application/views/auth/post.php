<style>
	
	.divider3
	{
	  background-image:linear-gradient(to right, white, red, white 38%);

	}
</style>

<h2>Home!</h2>
        <div class="divider3"></div>
        <p>Simple Factorial is the same as Simple * Simple-1 * Simple-2 * Simple-3 ; or in other words, a whole lot of simple. This template is meant to be really simple to use, and really simple to naviagate. It should also do well with search engines for that reason.</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut dapibus elementum dui. Mauris feugiat cursus urna. Suspendisse non turpis at purus vulputate vehicula. Nullam sagittis imperdiet turpis. Nunc posuere ornare dui.  </p>