
	<header id="head" class="secondary">
            <div class="container">
                  
                </div>
    </header>


<div class="container">


</div>
	<div id="courses">
		<section class="container">
			<h3>Different Categories</h3>
			<div class="row">
				<div class="col-md-4">
					<div class="featured-box"> 
					 			<?php
                                        
                                        include "../functions/connect.php";
                                      
                                        $sql = "SELECT * FROM `tbl_category` ";
                                        $run = mysql_query($sql);

                                        while($row=mysql_fetch_array($run)){
                                        
                                            $id = $row['cat_Id'];
                                            $name = $row['name'];
                                            $description = $row['description'];
                                            ?>
						<div class="text">
							<h3><?php echo $name;?></h3>
							<?php echo $description;?>
							</div>
							    <?php }?>
					</div>
				</div>
				
			</div>

		</section>
	</div>
  
			<div class="social text-center">
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-dribbble"></i></a>
				<a href="#"><i class="fa fa-flickr"></i></a>
				<a href="#"><i class="fa fa-github"></i></a>
			</div>

			<div class="clear"></div>
			<!--CLEAR FLOATS-->
		</div>
		
