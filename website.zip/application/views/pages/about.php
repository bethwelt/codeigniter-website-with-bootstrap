

	<header id="head" class="secondary">
            <div class="container">
                  
                </div>
    </header>

 <!-- container -->
    <section class="container">
        <div class="row">
            <!-- main content -->
            <section class="col-sm-8 maincontent">
                <h3>About Us</h3>
                <p>
                    <img src="../images/csit.png" alt="" class="img-rounded pull-right" width="300">
                    Works with computers and Internet networks in a variety of different settings. 
                    Most corporations have entire IT departments that help keep employees connected and websites in working order, though these are by no means the only jobs available. Schools, non-profit organizations, and basically all entities with a need for computer services and Internet technology employ people with IT expertise.
                    These sorts of people often also work for computer company themselves, providing help and support directly to clients. 
                </p>
                <p>The day-to-day aspects of this job can vary, but in nearly all cases the work involves maintaining computer systems, keeping networks in working order, and being available to solve problems and address complaints as they arise.</p>
                            </section>
            <!-- /main -->

            <!-- Sidebar -->
            <aside class="col-sm-4 sidebar sidebar-right">

                <div class="panel">
                    <h4>Latest Topic</h4>
                    <?php
                                        
                                        include "../functions/connect.php";
                                      
                                        $sql = "SELECT * FROM `tbl_topic` ";
                                        $run = mysql_query($sql);

                                        while($row=mysql_fetch_array($run)){
                                        
                                            $id = $row['topic_Id'];
                                            $title = $row['title'];
                                         
                                            ?>
                   <ul class="list-unstyled list-spaces">
                        <li><a href="../functions/alert.php"><?php echo ucfirst($title);?></a><br>
                            <span class="small text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi, laborum.</span></li>
                      <?php 
                        }
                      ?>
                    </ul>
                </div>

            </aside>
            <!-- /Sidebar -->

        </div>
    </section>
    <!-- /container -->

  
