<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="free-educational-responsive-web-template-webEdu">
	<meta name="author" content="webThemez.com">
	<title>website-</title>
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css');?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css');?>"> 
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-theme.css');?>" media="screen"> 
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css');?>">
    <link rel='stylesheet' id='camera-css'  href='<?php echo base_url('assets/css/camera.css');?>' type='text/css' media='all'> 
   <link rel="icon" type="image/png"  href="<?php echo base_url('images/favicon.png');?>">
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="<?php echo base_url('js/html5shiv.js');?>"></script>
	<script src="<?php echo base_url('js/respond.min.js');?>"></script>
	<![endif]-->
</head>

<body>		<!-- Fixed navbar -->
	<div class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<a class="navbar-brand" href="<?php echo base_url('/');?>">
					<img src="<?php echo base_url('images/logo.png');?>" alt=""></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right mainNav">
					<li ><a href="<?php echo base_url('/');?>">Home</a></li>
					
					<li><a href="<?php echo base_url('index.php/products');?>">Our Work</a></li>
                                        <li><a href="<?php echo base_url('index.php/services');?>"> Services</a></li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Login <b class="caret"></b></a>
						<ul class="dropdown-menu">
						
							<li><a href="<?php echo base_url('index.php/auth/login');?>">Login</a></li>
						</ul>
					</li>
                                        <li ><a href="<?php echo base_url('index.php/about');?>">About Us</a></li>
					<li><a href="<?php echo base_url('index.php/contact');?>">Contact Us</a></li>

				</ul>
			</div>
			<!--/.nav-collapse -->
		</div>
	</div>

  
