



	<!-- Header -->
	<header id="head">
		<div class="container">
             <div class="heading-text">							
							<h1 class="animated flipInY delay1">Start With Us Today...</h1>
							<p>We are the leading in the desigh of Applications.</p>
						</div>
            
					<div class="fluid_container">                       
                    <div class="camera_wrap camera_emboss pattern_1" id="camera_wrap_4">
                        <div data-thumb="images/slides/thumbs/img1.jpg" data-src="images/slides/img1.jpg">
                            <h2>We develop.</h2>
                        </div> 
    <div data-thumb="images/slides/thumbs/img1.jpg" data-src="images/slides/img1.jpg">
                            <h2>We Nature.</h2>
                        </div> 
    <div data-thumb="images/slides/thumbs/img1.jpg" data-src="images/slides/img1.jpg">
                            <h2>We Prosper.</h2>
                        </div> 
                        <div data-thumb="images/slides/thumbs/img2.jpg" data-src="images/slides/img2.jpg">
                        </div>
                        <div data-thumb="images/slides/thumbs/img3.jpg" data-src="images/slides/img3.jpg">
                        </div> 
 <div data-thumb="images/slides/thumbs/img3.jpg" data-src="images/slides/img3.jpg">
                        </div>
                        <div data-thumb="images/slides/thumbs/img4.jpg" data-src="images/slides/img4.jpg">
                        </div> 
 <div data-thumb="images/slides/thumbs/img5.jpg" data-src="images/slides/img5.jpg">
                        </div>
                        <div data-thumb="images/slides/thumbs/img6.jpg" data-src="images/slides/img6.jpg">
                        </div> 
 <div data-thumb="images/slides/thumbs/img7.jpg" data-src="images/slides/img7.jpg">
                        </div>
                        <div data-thumb="images/slides/thumbs/img8.jpg" data-src="images/slides/img8.jpg">
                        </div> 
                    </div><!-- #camera_wrap_3 -->
                </div><!-- .fluid_container -->
		</div>
	</header>
	<!-- /Header -->

  
		

